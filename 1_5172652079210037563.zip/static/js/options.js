!function(e) {
    var t = {};
    function a(r) {
        if (t[r])
            return t[r].exports;
        var n = t[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(n.exports, n, n.exports, a),
        n.l = !0,
        n.exports
    }
    a.m = e,
    a.c = t,
    a.d = function(e, t, r) {
        a.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: r
        })
    }
    ,
    a.r = function(e) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }),
        Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }
    ,
    a.t = function(e, t) {
        if (1 & t && (e = a(e)),
        8 & t)
            return e;
        if (4 & t && "object" === typeof e && e && e.__esModule)
            return e;
        var r = Object.create(null);
        if (a.r(r),
        Object.defineProperty(r, "default", {
            enumerable: !0,
            value: e
        }),
        2 & t && "string" != typeof e)
            for (var n in e)
                a.d(r, n, function(t) {
                    return e[t]
                }
                .bind(null, n));
        return r
    }
    ,
    a.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        }
        : function() {
            return e
        }
        ;
        return a.d(t, "a", t),
        t
    }
    ,
    a.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }
    ,
    a.p = "/",
    a(a.s = 23)
}({
    23: function(e, t) {
        var a, r = {
            passengers: [],
            childs: []
        }, n = ["select_user", "select_journey", "select_payment", "select_plan"], s = ["mode", "user", "pass"], o = ["from", "to", "date", "num", "quota", "coach", "boarding", "pt_max_fare"], d = ["payoption", "bank", "payUsing", "type", "cnum", "em", "ey", "name", "pin", "cvv", "password", "subBank", "userType", "corpId", "userId", "d3password", "hdfcPgMode", "cotp", "cemail", "cmobile", "NBBank"], c = ["check", "childBerthOpt", "name", "age", "gender", "berth", "nationality", "idCardType", "idCardNumber", "food"], p = ["check", "name", "age", "gender"], l = !0, i = !1, u = void 0;
        try {
            for (var v, y = ["savePassengers", "savePlan", "saveBook", "savePlan2", "saveBook2", "saveSettings"].concat(n, s, o, ["login_user", "journey", "payment", "mobile", "selected_passengers", "autoUpgrade", "onlyConfirmBerths", "prefCoachOpt", "coachID", "atasOption", "address-flat", "address-street", "address-area", "address-PIN", "address-postOffice", "address-City", "address-State", "pair", "auto_book"], d, ["auto_payment", "auto_sc", "auto_passenger", "auto_start_payment", "auto_refresh", "passenger_page_delay", "passenger_page_force_submit", "proxy_active", "proxy_mode", "proxy_provider", "proxy_id", "proxy_host", "proxy_port", "proxy_username", "proxy_password", "popup", "popup_width", "popup_height", "resend_otp", "resend_otp_time", "resend_otp_count"])[Symbol.iterator](); !(l = (v = y.next()).done); l = !0) {
                var h = v.value;
                r[h] = document.getElementById(h)
            }
        } catch (H) {
            i = !0,
            u = H
        } finally {
            try {
                l || null == y.return || y.return()
            } finally {
                if (i)
                    throw u
            }
        }
        for (var g = 0; g < 24; g++) {
            for (var _ = {}, m = 0; m < c.length; m++) {
                var f = c[m];
                _[f] = window.document.getElementById(f + g)
            }
            r.passengers.push(_)
        }
        for (var E = 24; E < 26; E++) {
            for (var b = {}, x = 0; x < p.length; x++) {
                var k = p[x];
                b[k] = window.document.getElementById(k + E)
            }
            r.childs.push(b)
        }
        function w() {
            var e = a.selected.user;
            $(".btn-round[data-change='select_user'][data-value='" + e + "']").addClass("active"),
            r.select_user.value = e;
            for (var t = 0; t < s.length; t++) {
                var n = s[t];
                r[n].value = a.users[e][n]
            }
        }
        function S() {
            var e = 0
              , t = !0
              , n = !1
              , s = void 0;
            try {
                for (var o, d = r.login_user.children[Symbol.iterator](); !(t = (o = d.next()).done); t = !0) {
                    o.value.textContent = a.users[e++].user || "User " + e
                }
            } catch (H) {
                n = !0,
                s = H
            } finally {
                try {
                    t || null == d.return || d.return()
                } finally {
                    if (n)
                        throw s
                }
            }
        }
        function T() {
            var e = a.selected.journey;
            $(".btn-round[data-change='select_journey'][data-value='" + e + "']").addClass("active"),
            r.select_journey.value = e;
            for (var t = 0; t < o.length; t++) {
                var n = o[t];
                r[n].value = a.journies[e][n]
            }
        }
        function C() {
            var e = 0
              , t = !0
              , n = !1
              , s = void 0;
            try {
                for (var o, d = r.journey.children[Symbol.iterator](); !(t = (o = d.next()).done); t = !0) {
                    o.value.textContent = "Journey " + (e + 1) + ": " + (a.journies[e].from.split(" - ")[1] || "FROM") + " - " + (a.journies[e].to.split(" - ")[1] || "TO") + " - " + (a.journies[e].date || "DATE") + " - " + (a.journies[e].num || "Train #") + " - " + a.journies[e].quota + " - " + a.journies[e].coach,
                    e++
                }
            } catch (H) {
                n = !0,
                s = H
            } finally {
                try {
                    t || null == d.return || d.return()
                } finally {
                    if (n)
                        throw s
                }
            }
        }
        function N() {
            var e = 0
              , t = !0
              , n = !1
              , s = void 0;
            try {
                for (var o, d = r.selected_passengers.children[Symbol.iterator](); !(t = (o = d.next()).done); t = !0) {
                    o.value.textContent = "P" + (e + 1) + ": " + (a.passengers[e].name || "Name") + " - " + (a.passengers[e].age || "Age") + " - " + (a.passengers[e].gender || "Gender"),
                    e++
                }
            } catch (H) {
                n = !0,
                s = H
            } finally {
                try {
                    t || null == d.return || d.return()
                } finally {
                    if (n)
                        throw s
                }
            }
            $("#selected_passengers")[0].dispatchEvent(new Event("chosen:updated"))
        }
        function A() {
            var e = a.selected.plan;
            $(".btn-round[data-change='select_plan'][data-value='" + e + "']").addClass("active"),
            r.select_plan.value = e;
            for (var t = 0; t < 2; t++) {
                a.plans[e].childs[t].check && (r.childs[t].check.checked = !0);
                for (var n = ["name", "age", "gender"], s = 0; s < n.length; s++) {
                    var o = n[s];
                    r.childs[t][o].value = a.plans[e].childs[t][o]
                }
            }
            for (var d = ["login_user", "journey", "payment", "mobile", "coachID", "address-flat", "address-street", "address-area", "address-PIN", "address-postOffice", "address-City", "address-State", "pair", "auto_book"], c = 0; c < d.length; c++) {
                var p = d[c];
                r[p].value = a.plans[e][p]
            }
            $("#selected_passengers").val(a.plans[e].selected_passengers),
            $("#selected_passengers")[0].dispatchEvent(new Event("chosen:updated"));
            for (var l = ["autoUpgrade", "atasOption", "onlyConfirmBerths", "prefCoachOpt"], i = 0; i < l.length; i++) {
                var u = l[i];
                r[u].checked = a.plans[e][u]
            }
            for (var v = 0; v < r.bookingCond.length; v++)
                if (r.bookingCond[v].value === a.plans[e].bookingCond) {
                    r.bookingCond[v].checked = !0;
                    break
                }
            r.onlyConfirmBerths.dispatchEvent(new Event("click")),
            r["address-PIN"].dispatchEvent(new Event("change"))
        }
        function j() {
            var e = a.selected.payment;
            $(".btn-round[data-change='select_payment'][data-value='" + e + "']").addClass("active"),
            r.select_payment.value = e,
            r.payoption.value = a.payments[e].payoption;
            for (var t = 0; t < d.length; t++) {
                var n = d[t];
                r[n].value = a.payments[e][n],
                r[n].dispatchEvent(new Event("update-ui"))
            }
        }
        function O() {
            var e = 0
              , t = !0
              , n = !1
              , s = void 0;
            try {
                for (var o, d = r.payment.children[Symbol.iterator](); !(t = (o = d.next()).done); t = !0) {
                    var c = o.value
                      , p = "P" + (e + 1) + ": " + ($("#bank").find("[value='" + a.payments[e].bank + "']").text() || "Bank") + " - " + a.payments[e].payUsing + " - ";
                    "" === a.payments[e].payUsing || "WALLET" === a.payments[e].payUsing || "UPI" === a.payments[e].payUsing || "NB" === a.payments[e].payUsing ? p += a.payments[e].userId : p += a.payments[e].cnum,
                    p += " - " + ($("#payoption").children("[value='" + a.payments[e].payoption + "']").text() || "Payment Type"),
                    c.textContent = p,
                    e++
                }
            } catch (H) {
                n = !0,
                s = H
            } finally {
                try {
                    t || null == d.return || d.return()
                } finally {
                    if (n)
                        throw s
                }
            }
        }
        function I(e) {
            var t = e.target.id
              , n = r.select_user.value;
            a.users[n][t] = r[t].value,
            chrome.storage.local.set({
                users: a.users
            }),
            S()
        }
        function P(e) {
            var t = e.target.id
              , n = r.select_journey.value;
            a.journies[n][t] = r[t].value,
            chrome.storage.local.set({
                journies: a.journies
            }),
            C()
        }
        function B(e) {
            var t = e.target.id;
            "select_user" === t ? (a.selected.user = r.select_user.value,
            w(),
            chrome.runtime.sendMessage({
                type: "EVENT",
                TAG: "CHANGED_USER",
                DETAILS: {
                    selected: a.selected.user
                }
            })) : "select_journey" === t ? (a.selected.journey = r.select_journey.value,
            T(),
            chrome.runtime.sendMessage({
                type: "EVENT",
                TAG: "CHANGED_JOURNEY",
                DETAILS: {
                    selected: a.selected.journey
                }
            })) : "select_payment" === t ? (a.selected.payment = r.select_payment.value,
            j(),
            chrome.runtime.sendMessage({
                type: "EVENT",
                TAG: "CHANGED_PAYMENT",
                DETAILS: {
                    selected: a.selected.payment
                }
            })) : "select_plan" === t && (a.selected.plan = r.select_plan.value,
            A(),
            chrome.runtime.sendMessage({
                type: "EVENT",
                TAG: "CHANGED_PLAN",
                DETAILS: {
                    selected: a.selected.plan
                }
            })),
            chrome.storage.local.set({
                selected: a.selected
            })
        }
        function L() {
            for (var e = 0; e < 24; e++) {
                a.passengers[e].check = !0,
                "" === r.passengers[e].name.value && (a.passengers[e].check = !1),
                a.passengers[e].childBerthOpt = r.passengers[e].childBerthOpt.checked;
                for (var t = 2; t < c.length; t++)
                    a.passengers[e][c[t]] = r.passengers[e][c[t]].value
            }
            chrome.storage.local.set({
                passengers: a.passengers
            }),
            $("#saved")[0].dispatchEvent(new Event("click")),
            N(),
            chrome.runtime.sendMessage({
                type: "EVENT",
                TAG: "SAVED_PASSENGER",
                DETAILS: {}
            })
        }
        function D() {
            for (var e = a.selected.plan, t = ["login_user", "journey", "payment", "mobile", "coachID", "address-flat", "address-street", "address-area", "address-PIN", "address-postOffice", "address-City", "address-State", "pair", "auto_book"], n = 0; n < t.length; n++) {
                var s = t[n];
                a.plans[e][s] = r[s].value
            }
            a.plans[e].selected_passengers = $("#selected_passengers").val();
            for (var o = ["autoUpgrade", "atasOption", "onlyConfirmBerths", "prefCoachOpt"], d = 0; d < o.length; d++) {
                var c = o[d];
                a.plans[e][c] = r[c].checked
            }
            for (var l = 0; l < r.bookingCond.length; l++)
                if (r.bookingCond[l].checked) {
                    a.plans[e].bookingCond = r.bookingCond[l].value;
                    break
                }
            for (var i = 0; i < 2; i++) {
                a.plans[e].childs[i].check = !0,
                "" === r.childs[i].name.value && (a.plans[e].childs[i].check = !0);
                for (var u = 1; u < p.length; u++)
                    a.plans[e].childs[i][p[u]] = r.childs[i][p[u]].value
            }
            chrome.storage.local.set({
                plans: a.plans
            }),
            $("#saved")[0].dispatchEvent(new Event("click")),
            chrome.runtime.sendMessage({
                type: "EVENT",
                TAG: "SAVED_PLAN",
                DETAILS: {
                    selected: e
                }
            });
        }
        function M() {
            D(),
            chrome.runtime.sendMessage({
                type: "BOOK",
                plan: a.selected.plan
            });
        }
        function G() {
            ["auto_payment", "auto_sc", "auto_passenger", "auto_start_payment", "passenger_page_force_submit", "popup", "resend_otp"].forEach(function(e) {
                a.basic[e] = r[e].checked
            }),
            a.basic.auto_refresh = parseInt(r.auto_refresh.value),
            a.basic.passenger_page_delay = parseInt(r.passenger_page_delay.value),
            a.basic.popup_width = r.popup_width.value,
            a.basic.popup_height = r.popup_height.value,
            a.basic.resend_otp_time = r.resend_otp_time.value,
            a.basic.resend_otp_count = r.resend_otp_count.value,
            r.proxy_active.checked ? a.proxy.active = !0 : a.proxy.active = !1,
            a.proxy.provider = r.proxy_provider.value,
            a.proxy.id = r.proxy_id.value,
            a.proxy.mode = r.proxy_mode.value,
            a.proxy.host = r.proxy_host.value,
            a.proxy.port = r.proxy_port.value,
            a.proxy.username = r.proxy_username.value,
            a.proxy.password = r.proxy_password.value,
            chrome.storage.local.set({
                basic: a.basic,
                proxy: a.proxy
            }),
            $("#saved")[0].dispatchEvent(new Event("click")),
            chrome.runtime.sendMessage({
                type: "EVENT",
                TAG: "SAVED_SETTINGS",
                DETAILS: {}
            })
        }
        function U(e) {
            var t = e.target.id
              , n = r.select_payment.value;
            a.payments[n][t] = r[t].value,
            chrome.storage.local.set({
                payments: a.payments
            }),
            O()
        }
        function V(e) {
            var t = ["1A", "2A", "3A", "CC", "FC", "SL", "2S", "3E"]
              , a = {
                Station_From: "",
                StationFromName: "",
                Station_To: "",
                StationToName: "",
                Error: ""
            }
              , r = -1;
            if ("" !== $("#date").val()) {
                var n = $("#date").val().split("-");
                r = ((n = new Date(n[2],n[1] - 1,n[0])).getDay() + 6) % 7
            }
            var s = e.data
              , o = ["", ""];
            if ("" !== s) {
                s = s.split("^");
                for (var d = 0; d < s.length; d++) {
                    s[d] += "~~~~~~";
                    var c = s[d].split("~");
                    if (0 === d)
                        a.Station_From = c[1],
                        a.StationFromName = c[2],
                        a.Station_To = c[3],
                        a.StationToName = c[4],
                        a.Error = c[5];
                    else {
                        var p = 0;
                        -1 !== r && "1" !== c[13].charAt(r) || (p = 1),
                        o[p] += "<tr>",
                        o[p] += "<td>" + c[0] + "</td><td>" + c[1] + "</td><td>" + c[7] + "</td><td>" + c[10] + "</td><td>" + c[9] + "</td><td>" + c[11] + "</td><td>" + c[12] + "</td>";
                        for (var l = 0; l < 7; l++)
                            "1" === c[13].charAt(l) ? o[p] += "<td>\u2714</td>" : o[p] += "<td>x</td>";
                        o[p] += "<td>";
                        for (var i = 0; i < 8; i++)
                            "1" === c[21].charAt(i) && (o[p] += '<a class="link" href="#' + c[0] + "~" + t[i] + "~" + c[7] + "~" + c[9] + '">' + t[i] + "</a> ");
                        o[p] += "</td></tr>"
                    }
                }
            }
            var u = o[1];
            "" !== o[0] ? u += "<tr class='danger'><td colspan='15'>Trains which doesn't run on given date</td><tr>" + o[0] : "" === u && (u += "<tr><td colspan='15' style='color:#f00'>No train found</td><tr>"),
            $("#trainlist").html(u),
            $("#overlay").css("display", "none")
        }
        function F() {
            var e = new Date;
            e.setSeconds(e.getSeconds() - a.basic.timeOffset);
            var t = e.getHours()
              , r = e.getMinutes()
              , n = e.getSeconds();
            t = R(t),
            r = R(r),
            n = R(n),
            document.getElementById("currentTime").textContent = t + ":" + r + ":" + n,
            setTimeout(F, 500)
        }
        function R(e) {
            return e < 10 && (e = "0" + e),
            e
        }
        r.bookingCond = window.document.getElementsByName("bookingCond"),
        $(".new-4-0-6").show(),
        $(".new-4-0-7").show(),
        $(".new-4-0-9").show(),
        $(".new-4-1-4").show(),
        $(".new-4-1-5").show(),
        chrome.storage.local.get(["basic", "selected", "plans", "users", "journies", "passengers", "payments", "tabs", "id", "proxy"], function(e) {
            a = e,
            F(),
            w(),
            S(),
            T(),
            C(),
            function() {
                for (var e = 0; e < 24; e++) {
                    a.passengers[e].check && (r.passengers[e].check.checked = !0);
                    for (var t = 2; t < c.length; t++)
                        r.passengers[e][c[t]].value = a.passengers[e][c[t]];
                    "" !== a.passengers[e].age && a.passengers[e].age <= 12 && (r.passengers[e].childBerthOpt.disabled = !1,
                    a.passengers[e].childBerthOpt || (r.passengers[e].childBerthOpt.checked = !1)),
                    "IN" !== a.passengers[e].nationality && (r.passengers[e].idCardType.disabled = !1,
                    r.passengers[e].idCardNumber.disabled = !1)
                }
            }(),
            N(),
            j(),
            O(),
            A(),
            ["auto_payment", "auto_sc", "auto_passenger", "auto_start_payment", "passenger_page_force_submit", "popup", "resend_otp"].forEach(function(e) {
                r[e].checked = !!a.basic[e]
            }),
            r.auto_refresh.value = a.basic.auto_refresh,
            r.passenger_page_delay.value = a.basic.passenger_page_delay,
            $(".proxy").show(),
            r.proxy_active.checked = !!a.proxy.active,
            r.proxy_mode.value = a.proxy.mode,
            r.proxy_provider.value = a.proxy.provider,
            r.proxy_id.value = a.proxy.id ? a.proxy.id : "",
            r.proxy_host.value = a.proxy.host,
            r.proxy_port.value = a.proxy.port,
            r.proxy_username.value = a.proxy.username,
            r.proxy_password.value = a.proxy.password,
            r.proxy_provider.dispatchEvent(new Event("change")),
            $(".popup").show(),
            r.popup_width.value = a.basic.popup_width,
            r.popup_height.value = a.basic.popup_height,
            $(".resend_otp_div").show(),
            r.resend_otp_time.value = a.basic.resend_otp_time,
            r.resend_otp_count.value = a.basic.resend_otp_count ? a.basic.resend_otp_count : "1";
            for (var t = 0; t < s.length; t++)
                r[s[t]].addEventListener("change", I);
            for (var p = 0; p < o.length; p++)
                r[o[p]].addEventListener("change", P);
            for (var l = 0; l < n.length; l++)
                r[n[l]].addEventListener("change", B);
            for (var i = 0; i < d.length; i++) {
                var u = d[i];
                r[u].addEventListener("change", U)
            }
            r.savePassengers.addEventListener("click", L),
            r.savePlan.addEventListener("click", D),
            r.saveBook.addEventListener("click", M),
            r.savePlan2.addEventListener("click", D),
            r.saveBook2.addEventListener("click", M),
            r.saveSettings.addEventListener("click", G)
        }),
        $("#num").click(function() {
            chrome.runtime.sendMessage({
                type: "TRAINLIST",
                fromStation: $("#from").val(),
                toStation: $("#to").val()
            }, V)
        }),
        $("#reset").show(),
        $("#resetconfirm").click(function() {
            chrome.runtime.sendMessage({
                type: "RESET"
            })
        }),
        window.addEventListener("message", function(e) {
            if (0 === window.location.href.indexOf(e.origin) && e.source === window)
                try {
                    var t = JSON.parse(e.data);
                    t.type && t.type === "TP_OTP_NEW_" + a.id && (console.log("New otp received by extension"),
                    chrome.storage.local.set({
                        otp: t.data
                    }))
                } catch (r) {}
            return !0
        })
    }
});
