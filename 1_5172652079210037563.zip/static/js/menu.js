! function (e) {
    var t = {};

    function n(i) {
        if (t[i]) return t[i].exports;
        var o = t[i] = {
            i: i,
            l: !1,
            exports: {}
        };
        return e[i].call(o.exports, o, o.exports, n), o.l = !0, o.exports
    }
    n.m = e, n.c = t, n.d = function (e, t, i) {
        n.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: i
        })
    }, n.r = function (e) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, n.t = function (e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" === typeof e && e && e.__esModule) return e;
        var i = Object.create(null);
        if (n.r(i), Object.defineProperty(i, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var o in e) n.d(i, o, function (t) {
                return e[t]
            }.bind(null, o));
        return i
    }, n.n = function (e) {
        var t = e && e.__esModule ? function () {
            return e.default
        } : function () {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "/", n(n.s = 19)
}({
    19: function (e, t) {
        ! function () {
            var e, t = {
                version: document.getElementById("version"),
                buttonActivate: document.getElementById("buttonActivate"),
                imgActivate: document.getElementById("imgActivate"),
                plan: document.getElementById("plan")
            };
            chrome.storage.local.get(["active", "basic", "permissions"], function (n) {
                var manifestData = chrome.runtime.getManifest();
                t.version.textContent = manifestData.version, (e = n.active) && (t.buttonActivate.classList.toggle("activated"), t.imgActivate.title = "Deactivate"), n.permissions.multiContainer || (document.getElementById("ask-permission").style.display = null, document.getElementById("plans").style.display = "none", document.getElementById("ask-permission").addEventListener("click", function (e) {
                    chrome.permissions.request({
                        permissions: ["tabs", "webNavigation", "cookies"],
                        origins: ["<all_urls>"]
                    }, function (e) {
                        e ? (chrome.runtime.sendMessage({
                            type: "PERMISSION_GRANTED",
                            permission: "multiContainer"
                        }), document.getElementById("ask-permission").style.display = "none", document.getElementById("plans").style.display = null) : chrome.runtime.sendMessage({
                            type: "PERMISSION_DENIED",
                            permission: "multiContainer"
                        })
                    })
                }))
            }), t.buttonActivate.onclick = function () {
                t.buttonActivate.classList.toggle("activated"), 
                e = !e, 
                t.imgActivate.title = e ? "Deactivate" : "Activate", 
                chrome.storage.local.set({
                    active: e
                })
            }, t.plan.onclick = function () {
                chrome.runtime.sendMessage({
                    type: "PLAN"
                })
            }, document.querySelectorAll(".btn-round").forEach(function (e) {
                e.addEventListener("click", function (e) {
                    chrome.runtime.sendMessage({
                        type: "BOOK",
                        plan: e.target.dataset.plan
                    })
                })
            })
        }()
    }
});