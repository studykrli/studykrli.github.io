(function(){
    document.querySelectorAll(".btn-round").forEach(element => {
		element.addEventListener('click',e=>{
			chrome.runtime.sendMessage({type: "BOOK_AND_CLOSE_TAB",plan:e.target.dataset.plan});
		})
	});
})();

document.getElementById("block").onclick = function(e){
    chrome.runtime.sendMessage({
        type: "BLOCK_TAB"
    });
}