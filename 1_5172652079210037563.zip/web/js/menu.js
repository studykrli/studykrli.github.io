window.onload = function(){
    document.getElementById('proxy_toggle').onclick = function(){
        chrome.storage.local.get(["proxy"], function (e) {
            e.proxy.active = !e.proxy.active;
            alert("Proxy is "+(e.proxy.active?"Active":"Disabled")+" Now!");
            chrome.storage.local.set({proxy:e.proxy});
        });
    }
}